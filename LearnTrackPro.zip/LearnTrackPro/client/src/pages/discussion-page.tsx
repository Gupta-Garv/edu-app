import { useState } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import MainLayout from "@/components/layout/main-layout";
import DiscussionThread from "@/components/discussions/discussion-thread";
import { DiscussionWithDetails, InsertReply } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function DiscussionPage() {
  const [_, params] = useRoute("/discussions/:id");
  const discussionId = params ? parseInt(params.id) : 0;
  const { user } = useAuth();
  const { toast } = useToast();

  // Fetch discussion details
  const {
    data: discussion,
    isLoading,
    error,
  } = useQuery<DiscussionWithDetails>({
    queryKey: [`/api/discussions/${discussionId}`],
    enabled: !!discussionId,
  });

  // Create reply mutation
  const createReplyMutation = useMutation({
    mutationFn: async (data: InsertReply) => {
      const res = await apiRequest("POST", "/api/replies", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/discussions/${discussionId}`] });
      toast({
        title: "Reply posted",
        description: "Your reply has been posted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to post reply: " + error.message,
        variant: "destructive",
      });
    },
  });

  const handleReply = async (content: string, discussionId: number, parentId?: number) => {
    if (!user) return;

    await createReplyMutation.mutateAsync({
      discussionId,
      userId: user.id,
      content,
      parentId
    });
  };

  if (!discussionId || !user) return null;

  return (
    <MainLayout title="Discussion">
      {/* Back link */}
      <div className="mb-4">
        <Link href={`/courses/${discussion?.courseId || ''}`}>
          <a className="inline-flex items-center text-sm text-gray-500 hover:text-primary">
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back to Course
          </a>
        </Link>
      </div>

      {isLoading ? (
        <Card>
          <CardContent className="p-6">
            <Skeleton className="h-8 w-3/4 mb-6" />
            <div className="flex mb-4">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="ml-3 flex-1">
                <Skeleton className="h-5 w-32 mb-1" />
                <Skeleton className="h-4 w-48" />
              </div>
            </div>
            <Skeleton className="h-32 w-full mb-4" />
            <div className="flex justify-between">
              <Skeleton className="h-8 w-24" />
              <Skeleton className="h-8 w-24" />
            </div>
          </CardContent>
        </Card>
      ) : error ? (
        <Card>
          <CardContent className="p-6 text-center">
            <p>Failed to load discussion. Please try again later.</p>
          </CardContent>
        </Card>
      ) : discussion ? (
        <DiscussionThread 
          discussion={discussion}
          currentUserId={user.id}
          onReply={handleReply}
        />
      ) : null}
    </MainLayout>
  );
}
