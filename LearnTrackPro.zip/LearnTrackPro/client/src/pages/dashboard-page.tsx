import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import MainLayout from "@/components/layout/main-layout";
import CourseCard from "@/components/courses/course-card";
import { Course, DiscussionWithDetails } from "@shared/schema";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronRight, Play, Compass } from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export default function DashboardPage() {
  const { user } = useAuth();

  // Fetch user's enrolled courses
  const {
    data: courses,
    isLoading: coursesLoading,
    error: coursesError,
  } = useQuery<Course[]>({
    queryKey: ["/api/user/courses"],
  });

  // Fetch user's progress
  const {
    data: progress,
    isLoading: progressLoading,
  } = useQuery({
    queryKey: ["/api/user/progress"],
  });

  // Fetch recent discussions
  const {
    data: discussions,
    isLoading: discussionsLoading,
  } = useQuery<DiscussionWithDetails[]>({
    queryKey: ["/api/recent-discussions"],
  });

  // Fetch recommended courses
  const {
    data: recommendedCourses,
    isLoading: recommendedLoading,
  } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  // Calculate course progress
  const calculateProgress = (courseId: number) => {
    if (!progress) return undefined;
    
    // This is a simplified version - would need proper module/lesson data
    // to calculate accurate progress
    return {
      completedLessons: 7,
      totalLessons: 12,
      percentage: 65
    };
  };

  if (!user) return null;

  return (
    <MainLayout title="Dashboard">
      {/* Welcome Section */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <h3 className="text-xl font-medium mb-2">Welcome back, {user.fullName.split(' ')[0]}!</h3>
          <p className="text-gray-500 mb-4">Continue learning where you left off or explore new courses.</p>
          <div className="flex flex-wrap gap-4">
            <Button className="flex items-center">
              <Play className="mr-2 h-4 w-4" />
              Continue Learning
            </Button>
            <Button variant="outline" className="border-primary text-primary flex items-center">
              <Compass className="mr-2 h-4 w-4" />
              Explore Courses
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* In Progress Courses */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium">Continue Learning</h3>
          <Link href="/courses">
            <Button variant="link" className="text-primary text-sm flex items-center p-0 h-auto">
              See all
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </Link>
        </div>
        
        {coursesLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-40 w-full" />
                <CardContent className="p-4">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-3" />
                  <Skeleton className="h-1 w-full mb-1" />
                  <div className="flex justify-between">
                    <Skeleton className="h-3 w-1/4" />
                    <Skeleton className="h-3 w-1/4" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : coursesError ? (
          <Card>
            <CardContent className="p-6 text-center">
              <p>Failed to load your courses. Please try again later.</p>
            </CardContent>
          </Card>
        ) : courses && courses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {courses.slice(0, 3).map((course) => (
              <CourseCard 
                key={course.id} 
                course={course} 
                progress={calculateProgress(course.id)}
              />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <p>You haven't enrolled in any courses yet.</p>
              <Link href="/marketplace">
                <Button className="mt-4">Browse Courses</Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
      
      {/* Latest Discussion Activity */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium">Recent Course Discussions</h3>
          <Link href="/discussions">
            <Button variant="link" className="text-primary text-sm flex items-center p-0 h-auto">
              See all
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </Link>
        </div>
        
        <Card>
          {discussionsLoading ? (
            <CardContent className="p-4 divide-y">
              {[1, 2].map((i) => (
                <div key={i} className="py-4 first:pt-0 last:pb-0">
                  <div className="flex mb-2">
                    <Skeleton className="h-8 w-8 rounded-full" />
                    <div className="ml-3">
                      <Skeleton className="h-4 w-32 mb-1" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                  </div>
                  <Skeleton className="h-4 w-full mb-3" />
                  <div className="flex justify-between">
                    <Skeleton className="h-8 w-20" />
                    <Skeleton className="h-8 w-32" />
                  </div>
                </div>
              ))}
            </CardContent>
          ) : discussions && discussions.length > 0 ? (
            <CardContent className="p-0 divide-y">
              {discussions.slice(0, 2).map((discussion) => (
                <div key={discussion.id} className="p-4">
                  <div className="flex justify-between mb-2">
                    <div className="flex items-center">
                      <Avatar className="h-8 w-8 bg-primary">
                        <AvatarFallback>
                          {discussion.user.fullName.split(' ').map(n => n[0]).join('').substring(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="ml-3">
                        <p className="font-medium">{discussion.user.fullName}</p>
                        <p className="text-xs text-gray-500">
                          {/* Would need to retrieve course name */}
                          Web Development • {new Date(discussion.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon">
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 24 24" 
                        fill="none" 
                        stroke="currentColor" 
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        className="h-5 w-5 text-gray-500"
                      >
                        <circle cx="12" cy="12" r="1" />
                        <circle cx="12" cy="5" r="1" />
                        <circle cx="12" cy="19" r="1" />
                      </svg>
                    </Button>
                  </div>
                  <p className="text-sm mb-3">{discussion.title}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-sm">
                      <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary">
                        <svg 
                          xmlns="http://www.w3.org/2000/svg" 
                          viewBox="0 0 24 24" 
                          fill="none" 
                          stroke="currentColor" 
                          strokeWidth="2" 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          className="h-4 w-4 mr-1"
                        >
                          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                        </svg>
                        <span>{discussion.replies.length} replies</span>
                      </Button>
                    </div>
                    <Link href={`/discussions/${discussion.id}`}>
                      <Button variant="link" className="text-primary text-sm p-0 h-auto">
                        View Discussion
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </CardContent>
          ) : (
            <CardContent className="p-6 text-center">
              <p>No recent discussions.</p>
            </CardContent>
          )}
        </Card>
      </div>
      
      {/* Recommended Courses */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium">Recommended for You</h3>
          <Link href="/marketplace">
            <Button variant="link" className="text-primary text-sm flex items-center p-0 h-auto">
              Browse all
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </Link>
        </div>
        
        {recommendedLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-40 w-full" />
                <CardContent className="p-4">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-3" />
                  <Skeleton className="h-4 w-full mb-3" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-6 w-16" />
                    <Skeleton className="h-9 w-24" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : recommendedCourses ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recommendedCourses.slice(0, 3).map((course) => (
              <CourseCard 
                key={course.id} 
                course={course} 
                showPrice={true}
                onPurchase={(courseId) => {
                  // Handle purchase
                  console.log(`Purchasing course ${courseId}`);
                }}
              />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <p>Failed to load recommendations. Please try again later.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}
