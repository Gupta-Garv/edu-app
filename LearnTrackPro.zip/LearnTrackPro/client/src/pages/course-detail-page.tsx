import { useEffect, useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import MainLayout from "@/components/layout/main-layout";
import VideoPlayer from "@/components/courses/video-player";
import ModuleAccordion from "@/components/courses/module-accordion";
import DiscussionList from "@/components/discussions/discussion-list";
import { CourseWithDetails, Discussion, InsertDiscussion, InsertProgress } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { ChevronRight, User, Clock, Star, StarHalf, MessageSquare, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function CourseDetailPage() {
  const [_, params] = useRoute("/courses/:id");
  const courseId = params ? parseInt(params.id) : 0;
  const [activeTab, setActiveTab] = useState("content");
  const [currentLessonId, setCurrentLessonId] = useState<number | null>(null);
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [newDiscussionTitle, setNewDiscussionTitle] = useState("");
  const [newDiscussionContent, setNewDiscussionContent] = useState("");
  const [showNewDiscussionForm, setShowNewDiscussionForm] = useState(false);

  // Fetch course details
  const {
    data: course,
    isLoading: courseLoading,
    error: courseError,
  } = useQuery<CourseWithDetails>({
    queryKey: [`/api/courses/${courseId}`],
    enabled: !!courseId,
  });

  // Fetch user progress
  const { data: progressData } = useQuery({
    queryKey: ["/api/user/progress"],
    enabled: !!courseId,
  });

  // Fetch course discussions
  const {
    data: discussions,
    isLoading: discussionsLoading,
  } = useQuery<Discussion[]>({
    queryKey: [`/api/courses/${courseId}/discussions`],
    enabled: !!courseId && activeTab === "discussion",
  });

  // Set completed lesson
  const markAsCompletedMutation = useMutation({
    mutationFn: async (data: InsertProgress) => {
      const res = await apiRequest("POST", "/api/user/progress", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/progress"] });
      toast({
        title: "Progress saved",
        description: "Your progress has been updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update progress: " + error.message,
        variant: "destructive",
      });
    },
  });

  // Create new discussion
  const createDiscussionMutation = useMutation({
    mutationFn: async (data: InsertDiscussion) => {
      const res = await apiRequest("POST", "/api/discussions", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/courses/${courseId}/discussions`] });
      toast({
        title: "Discussion created",
        description: "Your question has been posted.",
      });
      setNewDiscussionTitle("");
      setNewDiscussionContent("");
      setShowNewDiscussionForm(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create discussion: " + error.message,
        variant: "destructive",
      });
    },
  });

  // Set initial lesson
  useEffect(() => {
    if (course && course.modules.length > 0) {
      const firstModule = course.modules[0];
      if (firstModule.lessons.length > 0 && !currentLessonId) {
        setCurrentLessonId(firstModule.lessons[0].id);
      }
    }
  }, [course, currentLessonId]);

  // Find current lesson
  const currentLesson = course?.modules
    .flatMap(module => module.lessons)
    .find(lesson => lesson.id === currentLessonId);

  // Get completed lessons
  const completedLessons = new Set(
    progressData?.filter(p => p.completed).map(p => p.lessonId) || []
  );

  // Handle lesson selection
  const handleSelectLesson = (lessonId: number) => {
    setCurrentLessonId(lessonId);
    
    // If we're not on the content tab, switch to it
    if (activeTab !== "content") {
      setActiveTab("content");
    }
  };

  // Handle lesson completion
  const handleLessonComplete = () => {
    if (currentLessonId && user) {
      markAsCompletedMutation.mutate({
        userId: user.id,
        lessonId: currentLessonId,
        completed: true
      });
    }
  };

  // Handle new discussion submission
  const handleCreateDiscussion = () => {
    if (!newDiscussionTitle.trim() || !newDiscussionContent.trim()) {
      toast({
        title: "Validation error",
        description: "Please provide both title and content for your discussion.",
        variant: "destructive",
      });
      return;
    }

    createDiscussionMutation.mutate({
      courseId,
      userId: user!.id,
      title: newDiscussionTitle,
      content: newDiscussionContent
    });
  };

  if (!courseId) return null;

  return (
    <MainLayout title={course?.title || "Course Details"}>
      {/* Breadcrumb */}
      <div className="flex items-center mb-4 text-sm">
        <a href="#" onClick={(e) => { e.preventDefault(); setLocation("/"); }} className="text-gray-500 hover:text-primary">
          Dashboard
        </a>
        <ChevronRight className="h-4 w-4 mx-1 text-gray-400" />
        <a href="#" onClick={(e) => { e.preventDefault(); setLocation("/courses"); }} className="text-gray-500 hover:text-primary">
          My Courses
        </a>
        <ChevronRight className="h-4 w-4 mx-1 text-gray-400" />
        <span className="text-gray-700">{course?.title || "Loading..."}</span>
      </div>
      
      {/* Course header */}
      {courseLoading ? (
        <Card className="mb-6">
          <CardContent className="p-6">
            <Skeleton className="h-8 w-3/4 mb-4" />
            <div className="flex items-center mb-4">
              <Skeleton className="h-5 w-32 mr-4" />
              <Skeleton className="h-5 w-32 mr-4" />
              <Skeleton className="h-5 w-32" />
            </div>
            <Skeleton className="h-1 w-64 mb-2" />
            <Skeleton className="h-4 w-32" />
          </CardContent>
        </Card>
      ) : courseError ? (
        <Card className="mb-6">
          <CardContent className="p-6 text-center">
            <p>Failed to load course details. Please try again later.</p>
          </CardContent>
        </Card>
      ) : course ? (
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between">
              <div>
                <h2 className="text-2xl font-medium mb-2">{course.title}</h2>
                <div className="flex flex-wrap items-center mb-4 gap-y-2">
                  <div className="flex items-center mr-4">
                    <User className="h-4 w-4 text-gray-500 mr-1" />
                    <span className="text-gray-500">{course.instructor}</span>
                  </div>
                  <div className="flex items-center mr-4">
                    <Clock className="h-4 w-4 text-gray-500 mr-1" />
                    <span className="text-gray-500">{course.duration}</span>
                  </div>
                  <div className="flex items-center">
                    <div className="flex text-amber-400">
                      <Star className="h-4 w-4" />
                      <Star className="h-4 w-4" />
                      <Star className="h-4 w-4" />
                      <Star className="h-4 w-4" />
                      <StarHalf className="h-4 w-4" />
                    </div>
                    <span className="text-xs text-gray-500 ml-1">4.5</span>
                  </div>
                </div>
                <div className="h-1 bg-gray-200 rounded-full overflow-hidden w-full md:w-64 mb-2">
                  <div
                    className="h-full bg-green-500 rounded-full"
                    style={{
                      width: `${
                        course.modules.flatMap(m => m.lessons).length > 0
                          ? (completedLessons.size / course.modules.flatMap(m => m.lessons).length) * 100
                          : 0
                      }%`
                    }}
                  ></div>
                </div>
                <div className="text-xs text-gray-500">
                  {completedLessons.size} of {course.modules.flatMap(m => m.lessons).length} lessons completed 
                  ({Math.round((completedLessons.size / Math.max(course.modules.flatMap(m => m.lessons).length, 1)) * 100)}%)
                </div>
              </div>
              <div className="mt-4 md:mt-0">
                <Button className="flex items-center" onClick={() => {
                  if (currentLessonId) {
                    setActiveTab("content");
                  }
                }}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4 mr-2"
                  >
                    <circle cx="12" cy="12" r="10" />
                    <polygon points="10 8 16 12 10 16 10 8" />
                  </svg>
                  Continue Learning
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : null}
      
      {/* Course content tabs */}
      <Card className="mb-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="border-b border-gray-200">
            <TabsList className="overflow-x-auto border-0 bg-transparent">
              <TabsTrigger value="content" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none">
                Content
              </TabsTrigger>
              <TabsTrigger value="discussion" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none">
                Discussion
              </TabsTrigger>
              <TabsTrigger value="resources" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none">
                Resources
              </TabsTrigger>
              <TabsTrigger value="notes" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none">
                Notes
              </TabsTrigger>
              <TabsTrigger value="reviews" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none">
                Reviews
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* Content tab */}
          <TabsContent value="content" className="mt-0">
            <div className="p-6">
              {/* Video player section */}
              {currentLesson ? (
                <div className="mb-6">
                  <VideoPlayer 
                    videoUrl={currentLesson.videoUrl} 
                    title={currentLesson.title}
                    onComplete={handleLessonComplete}
                  />
                  <h3 className="text-lg font-medium mt-4">{currentLesson.title}</h3>
                  <p className="text-gray-500 text-sm">{currentLesson.description}</p>
                </div>
              ) : (
                <div className="mb-6 aspect-video bg-gray-100 flex items-center justify-center rounded-lg">
                  <p className="text-gray-500">Select a lesson to start learning</p>
                </div>
              )}
              
              {/* Course modules */}
              <div>
                <h3 className="font-medium mb-4">Course Content</h3>
                
                {courseLoading ? (
                  <>
                    <Skeleton className="h-20 w-full mb-4" />
                    <Skeleton className="h-20 w-full mb-4" />
                    <Skeleton className="h-20 w-full" />
                  </>
                ) : course?.modules.length === 0 ? (
                  <p className="text-center text-gray-500 py-4">No modules available for this course.</p>
                ) : (
                  course?.modules.map(module => (
                    <ModuleAccordion
                      key={module.id}
                      module={module}
                      currentLessonId={currentLessonId || undefined}
                      completedLessons={completedLessons}
                      onSelectLesson={handleSelectLesson}
                      isExpanded={module.lessons.some(lesson => lesson.id === currentLessonId)}
                    />
                  ))
                )}
              </div>
            </div>
          </TabsContent>
          
          {/* Discussion tab */}
          <TabsContent value="discussion" className="mt-0">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-medium">Course Discussion</h3>
                <Button 
                  onClick={() => setShowNewDiscussionForm(!showNewDiscussionForm)}
                  className="flex items-center"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  New Topic
                </Button>
              </div>
              
              {showNewDiscussionForm && (
                <Card className="mb-6">
                  <CardContent className="p-4">
                    <h4 className="font-medium mb-4">Post a New Question</h4>
                    <div className="space-y-4">
                      <div>
                        <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                          Title
                        </label>
                        <input
                          id="title"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                          placeholder="Enter a descriptive title for your question"
                          value={newDiscussionTitle}
                          onChange={(e) => setNewDiscussionTitle(e.target.value)}
                        />
                      </div>
                      <div>
                        <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-1">
                          Question Details
                        </label>
                        <Textarea
                          id="content"
                          placeholder="Describe your question in detail..."
                          className="min-h-32"
                          value={newDiscussionContent}
                          onChange={(e) => setNewDiscussionContent(e.target.value)}
                        />
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={() => setShowNewDiscussionForm(false)}>
                          Cancel
                        </Button>
                        <Button 
                          onClick={handleCreateDiscussion}
                          disabled={!newDiscussionTitle.trim() || !newDiscussionContent.trim() || createDiscussionMutation.isPending}
                        >
                          {createDiscussionMutation.isPending ? "Posting..." : "Post Question"}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Use the new DiscussionList component */}
              <DiscussionList 
                discussions={discussions || []} 
                isLoading={discussionsLoading}
                onNewDiscussion={() => setShowNewDiscussionForm(true)}
              />
            </div>
          </TabsContent>
          
          {/* Resources tab */}
          <TabsContent value="resources" className="mt-0">
            <div className="p-6">
              <h3 className="text-xl font-medium mb-4">Course Resources</h3>
              <p className="text-gray-500 mb-6">Download additional materials for this course.</p>
              
              <div className="space-y-2">
                <Card>
                  <CardContent className="p-4 flex justify-between items-center">
                    <div className="flex items-center">
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 24 24" 
                        fill="none" 
                        stroke="currentColor" 
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        className="h-6 w-6 text-blue-500 mr-3"
                      >
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                        <polyline points="14 2 14 8 20 8" />
                        <line x1="16" y1="13" x2="8" y2="13" />
                        <line x1="16" y1="17" x2="8" y2="17" />
                        <polyline points="10 9 9 9 8 9" />
                      </svg>
                      <div>
                        <p className="font-medium">Course Slides</p>
                        <p className="text-sm text-gray-500">PDF, 2.4 MB</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Download
                    </Button>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 flex justify-between items-center">
                    <div className="flex items-center">
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 24 24" 
                        fill="none" 
                        stroke="currentColor" 
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        className="h-6 w-6 text-green-500 mr-3"
                      >
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                        <polyline points="14 2 14 8 20 8" />
                        <line x1="12" y1="18" x2="12" y2="12" />
                        <line x1="9" y1="15" x2="15" y2="15" />
                      </svg>
                      <div>
                        <p className="font-medium">Exercise Files</p>
                        <p className="text-sm text-gray-500">ZIP, 8.7 MB</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Download
                    </Button>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 flex justify-between items-center">
                    <div className="flex items-center">
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 24 24" 
                        fill="none" 
                        stroke="currentColor" 
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        className="h-6 w-6 text-purple-500 mr-3"
                      >
                        <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z" />
                        <polyline points="13 2 13 9 20 9" />
                      </svg>
                      <div>
                        <p className="font-medium">Cheat Sheet</p>
                        <p className="text-sm text-gray-500">PDF, 1.2 MB</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Download
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
          
          {/* Notes tab */}
          <TabsContent value="notes" className="mt-0">
            <div className="p-6">
              <h3 className="text-xl font-medium mb-4">My Notes</h3>
              <p className="text-gray-500 mb-6">Take notes while learning to review later.</p>
              
              <div className="mb-6">
                <Textarea
                  placeholder="Write your notes here..."
                  className="min-h-48"
                />
                <div className="flex justify-end mt-2">
                  <Button>Save Notes</Button>
                </div>
              </div>
              
              <h4 className="font-medium mt-8 mb-4">Previous Notes</h4>
              <Card className="mb-4">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h5 className="font-medium">Module 3: DOM Manipulation</h5>
                    <span className="text-xs text-gray-500">05/15/2023</span>
                  </div>
                  <p className="text-sm text-gray-700">
                    Remember to use querySelector for single elements and querySelectorAll for multiple elements.
                    Event delegation is useful for dynamically added elements.
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h5 className="font-medium">Module 2: Functions</h5>
                    <span className="text-xs text-gray-500">04/28/2023</span>
                  </div>
                  <p className="text-sm text-gray-700">
                    Arrow functions don't have their own this context. They inherit from parent scope.
                    Remember the difference between function declarations and expressions.
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Reviews tab */}
          <TabsContent value="reviews" className="mt-0">
            <div className="p-6">
              <h3 className="text-xl font-medium mb-4">Course Reviews</h3>
              
              <div className="flex flex-col md:flex-row items-start gap-6 mb-8">
                <div className="bg-gray-50 p-6 rounded-lg text-center w-full md:w-48">
                  <div className="text-5xl font-bold text-primary mb-2">4.5</div>
                  <div className="flex justify-center text-amber-400 mb-2">
                    <Star className="h-5 w-5" />
                    <Star className="h-5 w-5" />
                    <Star className="h-5 w-5" />
                    <Star className="h-5 w-5" />
                    <StarHalf className="h-5 w-5" />
                  </div>
                  <p className="text-sm text-gray-500">Based on 230 reviews</p>
                </div>
                
                <div className="flex-1">
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <div className="w-16 text-sm">5 stars</div>
                      <div className="flex-1 h-2.5 bg-gray-200 rounded-full mr-2">
                        <div className="bg-primary h-2.5 rounded-full" style={{ width: "75%" }}></div>
                      </div>
                      <div className="w-10 text-sm text-gray-500">75%</div>
                    </div>
                    <div className="flex items-center">
                      <div className="w-16 text-sm">4 stars</div>
                      <div className="flex-1 h-2.5 bg-gray-200 rounded-full mr-2">
                        <div className="bg-primary h-2.5 rounded-full" style={{ width: "17%" }}></div>
                      </div>
                      <div className="w-10 text-sm text-gray-500">17%</div>
                    </div>
                    <div className="flex items-center">
                      <div className="w-16 text-sm">3 stars</div>
                      <div className="flex-1 h-2.5 bg-gray-200 rounded-full mr-2">
                        <div className="bg-primary h-2.5 rounded-full" style={{ width: "5%" }}></div>
                      </div>
                      <div className="w-10 text-sm text-gray-500">5%</div>
                    </div>
                    <div className="flex items-center">
                      <div className="w-16 text-sm">2 stars</div>
                      <div className="flex-1 h-2.5 bg-gray-200 rounded-full mr-2">
                        <div className="bg-primary h-2.5 rounded-full" style={{ width: "2%" }}></div>
                      </div>
                      <div className="w-10 text-sm text-gray-500">2%</div>
                    </div>
                    <div className="flex items-center">
                      <div className="w-16 text-sm">1 star</div>
                      <div className="flex-1 h-2.5 bg-gray-200 rounded-full mr-2">
                        <div className="bg-primary h-2.5 rounded-full" style={{ width: "1%" }}></div>
                      </div>
                      <div className="w-10 text-sm text-gray-500">1%</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-6">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-start mb-2">
                      <Avatar className="h-10 w-10 bg-blue-500">
                        <AvatarFallback>MJ</AvatarFallback>
                      </Avatar>
                      <div className="ml-3">
                        <div className="font-medium">Michael Johnson</div>
                        <div className="flex text-amber-400 mb-1">
                          <Star className="h-4 w-4" />
                          <Star className="h-4 w-4" />
                          <Star className="h-4 w-4" />
                          <Star className="h-4 w-4" />
                          <Star className="h-4 w-4" />
                        </div>
                        <div className="text-xs text-gray-500">Posted 2 weeks ago</div>
                      </div>
                    </div>
                    <p className="text-gray-700">
                      Excellent course! The instructor explains complex concepts in a way that's easy to understand. 
                      I particularly enjoyed the practical examples and projects. Highly recommended for anyone 
                      looking to learn JavaScript properly.
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-start mb-2">
                      <Avatar className="h-10 w-10 bg-green-500">
                        <AvatarFallback>AS</AvatarFallback>
                      </Avatar>
                      <div className="ml-3">
                        <div className="font-medium">Alicia Smith</div>
                        <div className="flex text-amber-400 mb-1">
                          <Star className="h-4 w-4" />
                          <Star className="h-4 w-4" />
                          <Star className="h-4 w-4" />
                          <Star className="h-4 w-4" />
                          <svg 
                            xmlns="http://www.w3.org/2000/svg" 
                            viewBox="0 0 24 24" 
                            fill="none" 
                            stroke="currentColor" 
                            strokeWidth="2" 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            className="h-4 w-4 text-gray-300"
                          >
                            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                          </svg>
                        </div>
                        <div className="text-xs text-gray-500">Posted 1 month ago</div>
                      </div>
                    </div>
                    <p className="text-gray-700">
                      Great course overall, but I wish there were more advanced topics covered in the later modules. 
                      The exercises were very helpful though, and I appreciated the instructor's teaching style. 
                      Would recommend for beginners and intermediate developers.
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-start mb-2">
                      <Avatar className="h-10 w-10 bg-purple-500">
                        <AvatarFallback>RT</AvatarFallback>
                      </Avatar>
                      <div className="ml-3">
                        <div className="font-medium">Robert Thompson</div>
                        <div className="flex text-amber-400 mb-1">
                          <Star className="h-4 w-4" />
                          <Star className="h-4 w-4" />
                          <Star className="h-4 w-4" />
                          <Star className="h-4 w-4" />
                          <Star className="h-4 w-4" />
                        </div>
                        <div className="text-xs text-gray-500">Posted 3 months ago</div>
                      </div>
                    </div>
                    <p className="text-gray-700">
                      I've taken several JavaScript courses before, but this one really stands out. 
                      The instructor breaks down complex topics into digestible chunks, and the 
                      progression from basic to advanced concepts is well thought out. The course 
                      projects are challenging but rewarding.
                    </p>
                  </CardContent>
                </Card>
              </div>
              
              <div className="flex justify-center mt-6">
                <Button variant="outline">Load More Reviews</Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </Card>
    </MainLayout>
  );
}
