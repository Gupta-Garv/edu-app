import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import MainLayout from "@/components/layout/main-layout";
import CourseCard from "@/components/courses/course-card";
import { Course, InsertUserCourse } from "@shared/schema";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Search, CreditCard, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function MarketplacePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [priceFilter, setPriceFilter] = useState("all");
  const [purchaseDialogOpen, setPurchaseDialogOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [paymentComplete, setPaymentComplete] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  // Fetch all available courses
  const {
    data: courses,
    isLoading,
    error,
  } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  // Fetch user's purchased courses
  const { data: userCourses } = useQuery<Course[]>({
    queryKey: ["/api/user/courses"],
    enabled: !!user,
  });

  // Purchase course mutation
  const purchaseMutation = useMutation({
    mutationFn: async (data: InsertUserCourse) => {
      const res = await apiRequest("POST", "/api/user/courses", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/courses"] });
      setPaymentComplete(true);
      
      // Reset after showing success message
      setTimeout(() => {
        setPurchaseDialogOpen(false);
        setSelectedCourse(null);
        setProcessingPayment(false);
        setPaymentComplete(false);
        
        toast({
          title: "Course purchased",
          description: "You now have access to this course.",
        });
      }, 2000);
    },
    onError: (error) => {
      setProcessingPayment(false);
      toast({
        title: "Purchase failed",
        description: "Failed to purchase course: " + error.message,
        variant: "destructive",
      });
    },
  });

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Search logic is handled in filteredCourses
  };

  // Filter courses
  const filteredCourses = courses
    ? courses.filter((course) => {
        // Filter by search query
        if (
          searchQuery &&
          !course.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !course.instructor.toLowerCase().includes(searchQuery.toLowerCase())
        ) {
          return false;
        }

        // Filter by category
        if (categoryFilter !== "all" && course.category !== categoryFilter) {
          return false;
        }

        // Filter by price
        if (priceFilter === "free" && course.price > 0) {
          return false;
        } else if (priceFilter === "paid" && course.price === 0) {
          return false;
        } else if (priceFilter === "under25" && (course.price === 0 || course.price > 2500)) {
          return false;
        } else if (priceFilter === "under50" && (course.price === 0 || course.price > 5000)) {
          return false;
        }

        return true;
      })
    : [];

  // Handle course purchase
  const handlePurchase = (course: Course) => {
    setSelectedCourse(course);
    setPurchaseDialogOpen(true);
  };

  // Process payment
  const processPayment = () => {
    if (!selectedCourse || !user) return;

    setProcessingPayment(true);

    // Simulate payment processing delay
    setTimeout(() => {
      purchaseMutation.mutate({
        userId: user.id,
        courseId: selectedCourse.id,
      });
    }, 1500);
  };

  // Check if course is already purchased
  const isCoursePurchased = (courseId: number) => {
    return userCourses?.some((c) => c.id === courseId) || false;
  };

  return (
    <MainLayout title="Course Marketplace">
      {/* Filters and search */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4 items-start md:items-center">
            <form onSubmit={handleSearch} className="relative flex-1 w-full">
              <Input
                type="text"
                placeholder="Search courses..."
                className="pr-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            </form>

            <div className="flex space-x-4 w-full md:w-auto">
              <div className="w-full md:w-40">
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="Web Development">Web Development</SelectItem>
                    <SelectItem value="Data Science">Data Science</SelectItem>
                    <SelectItem value="Business">Business</SelectItem>
                    <SelectItem value="UI/UX Design">UI/UX Design</SelectItem>
                    <SelectItem value="Cloud Computing">Cloud Computing</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="w-full md:w-40">
                <Select value={priceFilter} onValueChange={setPriceFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Price" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Prices</SelectItem>
                    <SelectItem value="free">Free</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="under25">Under $25</SelectItem>
                    <SelectItem value="under50">Under $50</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Courses grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="h-40 w-full" />
              <CardContent className="p-4">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2 mb-3" />
                <div className="flex justify-between items-center">
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-10 w-24" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : error ? (
        <Card>
          <CardContent className="p-6 text-center">
            <p>Failed to load courses. Please try again later.</p>
          </CardContent>
        </Card>
      ) : filteredCourses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map((course) => (
            <CourseCard
              key={course.id}
              course={course}
              showPrice={true}
              onPurchase={
                isCoursePurchased(course.id)
                  ? undefined // Disable purchase button if already purchased
                  : () => handlePurchase(course)
              }
            />
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-6 text-center">
            <p className="mb-4">
              {searchQuery || categoryFilter !== "all" || priceFilter !== "all"
                ? "No courses match your search criteria."
                : "No courses available at the moment."}
            </p>
            {(searchQuery || categoryFilter !== "all" || priceFilter !== "all") && (
              <Button
                onClick={() => {
                  setSearchQuery("");
                  setCategoryFilter("all");
                  setPriceFilter("all");
                }}
              >
                Clear Filters
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Purchase dialog */}
      <Dialog open={purchaseDialogOpen} onOpenChange={setPurchaseDialogOpen}>
        <DialogContent>
          {paymentComplete ? (
            <div className="text-center py-6">
              <div className="bg-green-100 rounded-full p-3 w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Check className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-medium mb-2">Purchase Successful!</h3>
              <p className="text-gray-500">You now have access to this course.</p>
            </div>
          ) : (
            <>
              <DialogHeader>
                <DialogTitle>Purchase Course</DialogTitle>
                <DialogDescription>
                  Complete your purchase to get instant access to this course.
                </DialogDescription>
              </DialogHeader>

              {selectedCourse && (
                <div className="space-y-4 py-4">
                  <div className="flex space-x-4 items-start">
                    <div className="h-20 w-20 rounded-md overflow-hidden bg-gray-100">
                      <img
                        src={selectedCourse.thumbnail}
                        alt={selectedCourse.title}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-medium">{selectedCourse.title}</h4>
                      <p className="text-sm text-gray-500">{selectedCourse.instructor}</p>
                      <p className="text-lg font-bold mt-1">${(selectedCourse.price / 100).toFixed(2)}</p>
                    </div>
                  </div>

                  <div className="border-t border-b border-gray-200 py-4">
                    <h4 className="font-medium mb-2">Payment Details</h4>
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm text-gray-500">Card Number</label>
                        <div className="relative">
                          <Input
                            placeholder="1234 5678 9012 3456"
                            disabled={processingPayment}
                          />
                          <CreditCard className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm text-gray-500">Expiration Date</label>
                          <Input placeholder="MM/YY" disabled={processingPayment} />
                        </div>
                        <div>
                          <label className="text-sm text-gray-500">CVV</label>
                          <Input placeholder="123" disabled={processingPayment} />
                        </div>
                      </div>
                      <div>
                        <label className="text-sm text-gray-500">Cardholder Name</label>
                        <Input placeholder="John Smith" disabled={processingPayment} />
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center text-sm">
                    <span>Subtotal:</span>
                    <span>${(selectedCourse.price / 100).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span>Tax:</span>
                    <span>${((selectedCourse.price * 0.1) / 100).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center font-medium">
                    <span>Total:</span>
                    <span>${((selectedCourse.price * 1.1) / 100).toFixed(2)}</span>
                  </div>
                </div>
              )}

              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setPurchaseDialogOpen(false)}
                  disabled={processingPayment}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={processPayment} 
                  disabled={processingPayment}
                  className="min-w-24"
                >
                  {processingPayment ? (
                    <span className="flex items-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing
                    </span>
                  ) : (
                    "Complete Purchase"
                  )}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
