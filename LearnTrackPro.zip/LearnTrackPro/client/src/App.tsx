import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";

import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import CoursesPage from "@/pages/courses-page";
import CourseDetailPage from "@/pages/course-detail-page";
import DiscussionPage from "@/pages/discussion-page";
import AdminCoursesPage from "@/pages/admin/courses-page";
import AddCoursePage from "@/pages/admin/add-course-page";
import MarketplacePage from "@/pages/marketplace-page";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      
      <ProtectedRoute path="/" component={DashboardPage} />
      <ProtectedRoute path="/courses" component={CoursesPage} />
      <ProtectedRoute path="/courses/:id" component={CourseDetailPage} />
      <ProtectedRoute path="/discussions/:id" component={DiscussionPage} />
      <ProtectedRoute path="/marketplace" component={MarketplacePage} />
      
      <ProtectedRoute path="/admin/courses" component={AdminCoursesPage} />
      <ProtectedRoute path="/admin/courses/add" component={AddCoursePage} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
