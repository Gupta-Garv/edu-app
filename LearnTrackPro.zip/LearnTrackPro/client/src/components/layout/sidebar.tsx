import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  School, 
  Home, 
  Book, 
  Award, 
  ShoppingCart, 
  Settings, 
  LogOut,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
}

export default function Sidebar({ mobileOpen, setMobileOpen }: SidebarProps) {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();

  if (!user) return null;

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const closeMobileMenu = () => {
    if (mobileOpen) {
      setMobileOpen(false);
    }
  };

  const isActive = (path: string) => {
    return location === path || location.startsWith(`${path}/`);
  };

  return (
    <div 
      className={cn(
        "fixed md:relative z-30 w-64 h-screen bg-white shadow-lg transition-transform duration-300 ease-in-out flex flex-col",
        mobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
      )}
    >
      {/* Logo */}
      <div className="p-4 border-b border-gray-200">
        <Link href="/" onClick={closeMobileMenu}>
          <div className="flex items-center space-x-2 cursor-pointer">
            <School className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold text-primary">LearnHub</h1>
          </div>
        </Link>
      </div>
      
      {/* User info */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white">
            <span>
              {user.username.substring(0, 2).toUpperCase()}
            </span>
          </div>
          <div>
            <p className="font-medium">{user.fullName || user.username}</p>
            <p className="text-sm text-gray-500">{user.email || ''}</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4">
        <ul>
          <li>
            <Link 
              href="/" 
              onClick={closeMobileMenu}
              className={cn(
                "flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100",
                isActive("/") && "border-l-4 border-primary bg-gray-100"
              )}
            >
              <Home className="mr-3 h-5 w-5" />
              <span>Dashboard</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/courses" 
              onClick={closeMobileMenu}
              className={cn(
                "flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100",
                isActive("/courses") && "border-l-4 border-primary bg-gray-100"
              )}
            >
              <Book className="mr-3 h-5 w-5" />
              <span>My Courses</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/marketplace" 
              onClick={closeMobileMenu}
              className={cn(
                "flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100",
                isActive("/marketplace") && "border-l-4 border-primary bg-gray-100"
              )}
            >
              <ShoppingCart className="mr-3 h-5 w-5" />
              <span>Marketplace</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/certificates" 
              onClick={closeMobileMenu}
              className={cn(
                "flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100",
                isActive("/certificates") && "border-l-4 border-primary bg-gray-100"
              )}
            >
              <Award className="mr-3 h-5 w-5" />
              <span>Certificates</span>
            </Link>
          </li>
          
          {/* Admin section */}
          {user.isAdmin && (
            <>
              <li className="px-4 pt-6 pb-2">
                <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  ADMIN
                </span>
              </li>
              <li>
                <Link 
                  href="/admin/courses" 
                  onClick={closeMobileMenu}
                  className={cn(
                    "flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100",
                    isActive("/admin/courses") && "border-l-4 border-primary bg-gray-100"
                  )}
                >
                  <FileText className="mr-3 h-5 w-5" />
                  <span>Manage Courses</span>
                </Link>
              </li>
            </>
          )}
        </ul>
      </nav>
      
      {/* Logout button */}
      <div className="p-4 border-t border-gray-200">
        <Button 
          variant="ghost" 
          className="flex w-full items-center text-gray-700 hover:text-primary"
          onClick={handleLogout}
          disabled={logoutMutation.isPending}
        >
          <LogOut className="mr-2 h-5 w-5" />
          <span>Logout</span>
        </Button>
      </div>
    </div>
  );
}
