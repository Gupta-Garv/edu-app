import { useState } from 'react';
import { ChevronDown, ChevronUp, Play, Check, Lock, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Module, Lesson } from '@shared/schema';

interface ModuleAccordionProps {
  module: Module & { lessons: Lesson[] };
  currentLessonId?: number;
  completedLessons: Set<number>;
  onSelectLesson: (lessonId: number) => void;
  isExpanded?: boolean;
}

export default function ModuleAccordion({ 
  module, 
  currentLessonId, 
  completedLessons,
  onSelectLesson,
  isExpanded = false
}: ModuleAccordionProps) {
  const [expanded, setExpanded] = useState(isExpanded);
  
  const totalDuration = module.lessons.reduce((total, lesson) => {
    // Convert "XX min" to minutes
    const minutes = parseInt(lesson.duration.split(' ')[0]) || 0;
    return total + minutes;
  }, 0);
  
  const completedCount = module.lessons.filter(lesson => 
    completedLessons.has(lesson.id)
  ).length;
  
  return (
    <div className="mb-4 border border-gray-200 rounded-lg">
      <div 
        className={cn(
          "flex justify-between items-center p-4 cursor-pointer",
          currentLessonId && module.lessons.some(l => l.id === currentLessonId) && "bg-primary/5"
        )}
        onClick={() => setExpanded(!expanded)}
      >
        <div>
          <h4 className="font-medium">{module.title}</h4>
          <p className="text-sm text-gray-500">
            {module.lessons.length} lessons • {totalDuration} min • {completedCount}/{module.lessons.length} completed
          </p>
        </div>
        {expanded ? (
          <ChevronUp className="h-5 w-5 text-gray-500" />
        ) : (
          <ChevronDown className="h-5 w-5 text-gray-500" />
        )}
      </div>
      
      {expanded && (
        <div className="border-t border-gray-200">
          {module.lessons.map((lesson, index) => {
            const isCompleted = completedLessons.has(lesson.id);
            const isCurrent = lesson.id === currentLessonId;
            
            return (
              <div 
                key={lesson.id}
                className={cn(
                  "flex items-center justify-between p-3 hover:bg-gray-50 border-b border-gray-200 last:border-b-0",
                  isCurrent && "bg-primary/5"
                )}
                onClick={() => onSelectLesson(lesson.id)}
              >
                <div className="flex items-center cursor-pointer">
                  {isCompleted ? (
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                  ) : isCurrent ? (
                    <Play className="h-5 w-5 text-primary mr-3" />
                  ) : index > completedCount && completedCount < index - 1 ? (
                    <Lock className="h-5 w-5 text-gray-300 mr-3" />
                  ) : (
                    <div className="h-5 w-5 border border-gray-300 rounded-full mr-3" />
                  )}
                  <span className={cn(
                    index > completedCount && completedCount < index - 1 ? "text-gray-400" : "",
                    isCurrent && "font-medium"
                  )}>
                    {lesson.title}
                  </span>
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>{lesson.duration}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
