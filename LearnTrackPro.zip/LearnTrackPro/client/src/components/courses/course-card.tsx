import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Course, Progress } from "@shared/schema";
import { Play, User, Clock } from "lucide-react";

interface CourseCardProps {
  course: Course;
  progress?: {
    completedLessons: number;
    totalLessons: number;
    percentage: number;
  };
  showPrice?: boolean;
  onPurchase?: (courseId: number) => void;
}

export default function CourseCard({ 
  course, 
  progress,
  showPrice = false,
  onPurchase
}: CourseCardProps) {
  return (
    <Card className="overflow-hidden h-full flex flex-col">
      <div className="relative h-40 overflow-hidden">
        <img 
          src={course.thumbnail} 
          alt={course.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3">
          <span className="text-white text-sm font-medium">{course.category}</span>
        </div>
      </div>
      <CardContent className="p-4 flex-1 flex flex-col">
        <h4 className="font-medium text-gray-700 mb-2 line-clamp-2">{course.title}</h4>
        <div className="flex items-center text-sm text-gray-500 mb-3">
          <User className="h-4 w-4 mr-1" />
          <span className="mr-2">{course.instructor}</span>
          <span className="mx-1">•</span>
          <Clock className="h-4 w-4 mx-1" />
          <span>{course.duration}</span>
        </div>
        
        {progress && (
          <div className="mb-3 mt-auto">
            <div className="h-1 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-green-500 rounded-full" 
                style={{ width: `${progress.percentage}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-xs mt-1">
              <span className="text-gray-500">{progress.percentage}% complete</span>
              <span className="text-primary">
                {progress.completedLessons}/{progress.totalLessons} lessons
              </span>
            </div>
          </div>
        )}
        
        {showPrice ? (
          <div className="flex justify-between items-center mt-auto">
            <span className="text-lg font-bold">${(course.price / 100).toFixed(2)}</span>
            <Button 
              size="sm"
              onClick={() => onPurchase && onPurchase(course.id)}
            >
              Add to Cart
            </Button>
          </div>
        ) : (
          <Link href={`/courses/${course.id}`}>
            <Button className="w-full mt-auto" variant="default">
              {progress ? (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Continue
                </>
              ) : (
                "Start Learning"
              )}
            </Button>
          </Link>
        )}
      </CardContent>
    </Card>
  );
}
