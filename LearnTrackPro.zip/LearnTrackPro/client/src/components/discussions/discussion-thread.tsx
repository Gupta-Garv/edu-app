import { useState } from 'react';
import { DiscussionWithDetails } from '@shared/schema';
import { User, ThumbsUp, MessageSquare, Reply, MoreVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import ReplyForm from './reply-form';
import { cn } from '@/lib/utils';

interface DiscussionThreadProps {
  discussion: DiscussionWithDetails;
  currentUserId: number;
  onReply: (content: string, discussionId: number, parentId?: number) => Promise<void>;
}

export default function DiscussionThread({ 
  discussion, 
  currentUserId,
  onReply
}: DiscussionThreadProps) {
  const [showReplyForm, setShowReplyForm] = useState<number | null>(null);
  const [replyText, setReplyText] = useState('');
  
  // Format date to relative time
  const formatDate = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffMins = Math.round(diffMs / (1000 * 60));
    const diffHours = Math.round(diffMs / (1000 * 60 * 60));
    const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffMins < 60) {
      return diffMins === 1 ? '1 minute ago' : `${diffMins} minutes ago`;
    }
    if (diffHours < 24) {
      return diffHours === 1 ? '1 hour ago' : `${diffHours} hours ago`;
    }
    if (diffDays === 1) {
      return 'Yesterday';
    }
    return `${diffDays} days ago`;
  };
  
  // Get user initials for avatar
  const getUserInitials = (user: { fullName?: string, username: string } | string) => {
    if (typeof user === 'string') {
      return user.substring(0, 2).toUpperCase();
    }
    
    if (user.fullName) {
      return user.fullName
        .split(' ')
        .map(name => name[0])
        .join('')
        .substring(0, 2)
        .toUpperCase();
    }
    return user.username.substring(0, 2).toUpperCase();
  };
  
  const handleReplySubmit = async (content: string, parentId?: number) => {
    await onReply(content, discussion.id, parentId);
    setShowReplyForm(null);
    setReplyText('');
  };
  
  // Determine background color based on username
  const getAvatarColor = (username: string) => {
    const colors = [
      'bg-blue-500',
      'bg-purple-500',
      'bg-green-500',
      'bg-yellow-500',
      'bg-red-500',
      'bg-indigo-500',
      'bg-pink-500',
      'bg-teal-500'
    ];
    
    // Simple hash function to pick a color
    let hash = 0;
    for (let i = 0; i < username.length; i++) {
      hash = username.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    return colors[Math.abs(hash) % colors.length];
  };
  
  return (
    <div className="bg-white rounded-lg shadow p-6">
      {/* Main discussion post */}
      <div className="mb-6 pb-6 border-b border-gray-200">
        <div className="flex justify-between mb-4">
          <div className="flex items-start">
            <Avatar className={getAvatarColor(discussion.user.username)}>
              <AvatarFallback>
                {getUserInitials(discussion.user)}
              </AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <div className="flex items-center">
                <p className="font-medium">{discussion.user.fullName}</p>
                {discussion.user.isAdmin && (
                  <Badge className="ml-2 bg-primary text-white">Instructor</Badge>
                )}
              </div>
              <p className="text-xs text-gray-500">Posted {formatDate(discussion.createdAt)}</p>
            </div>
          </div>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5 text-gray-500" />
          </Button>
        </div>
        
        <h3 className="text-lg font-medium mb-3">{discussion.title}</h3>
        <div className="text-gray-700 mb-4 whitespace-pre-line">
          {discussion.content}
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary">
              <ThumbsUp className="h-4 w-4 mr-1" />
              <span>12</span>
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary">
              <MessageSquare className="h-4 w-4 mr-1" />
              <span>{discussion.replies.length} replies</span>
            </Button>
          </div>
          <Button 
            variant="ghost"
            size="sm"
            className="text-primary"
            onClick={() => setShowReplyForm(discussion.id)}
          >
            <Reply className="h-4 w-4 mr-1" />
            <span>Reply</span>
          </Button>
        </div>
        
        {showReplyForm === discussion.id && (
          <ReplyForm 
            onSubmit={(content) => handleReplySubmit(content)}
            onCancel={() => setShowReplyForm(null)}
            currentUserInitials={getUserInitials(currentUserId.toString())}
          />
        )}
      </div>
      
      {/* Replies */}
      {discussion.replies.map(reply => (
        <div key={reply.id} className="ml-8 mb-6 pb-6 border-b border-gray-200 last:border-b-0 last:pb-0 last:mb-0">
          <div className="flex justify-between mb-4">
            <div className="flex items-start">
              <Avatar className={getAvatarColor(reply.user.username)}>
                <AvatarFallback>
                  {getUserInitials(reply.user)}
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <div className="flex items-center">
                  <p className="font-medium">{reply.user.fullName}</p>
                  {reply.user.isAdmin && (
                    <Badge className="ml-2 bg-primary text-white">Instructor</Badge>
                  )}
                </div>
                <p className="text-xs text-gray-500">Posted {formatDate(reply.createdAt)}</p>
              </div>
            </div>
            <Button variant="ghost" size="icon">
              <MoreVertical className="h-5 w-5 text-gray-500" />
            </Button>
          </div>
          
          <div className="text-gray-700 mb-4 whitespace-pre-line">
            {reply.content}
          </div>
          
          <div className="flex items-center justify-between">
            <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary">
              <ThumbsUp className="h-4 w-4 mr-1" />
              <span>8</span>
            </Button>
            <Button 
              variant="ghost"
              size="sm"
              className="text-primary"
              onClick={() => setShowReplyForm(reply.id)}
            >
              <Reply className="h-4 w-4 mr-1" />
              <span>Reply</span>
            </Button>
          </div>
          
          {showReplyForm === reply.id && (
            <ReplyForm 
              onSubmit={(content) => handleReplySubmit(content, reply.id)}
              onCancel={() => setShowReplyForm(null)}
              currentUserInitials={getUserInitials(currentUserId.toString())}
            />
          )}
          
          {/* Nested replies */}
          {reply.childReplies && reply.childReplies.length > 0 && (
            <div className="ml-8 mt-4 pt-4 border-l-2 border-gray-200 pl-4">
              {reply.childReplies.map(childReply => (
                <div key={childReply.id} className="mb-4 last:mb-0">
                  <div className="flex justify-between mb-2">
                    <div className="flex items-start">
                      <Avatar className={getAvatarColor(childReply.user.username)}>
                        <AvatarFallback>
                          {getUserInitials(childReply.user)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="ml-3">
                        <div className="flex items-center">
                          <p className="font-medium">{childReply.user.fullName}</p>
                          {childReply.user.isAdmin && (
                            <Badge className="ml-2 bg-primary text-white text-xs">Instructor</Badge>
                          )}
                        </div>
                        <p className="text-xs text-gray-500">Posted {formatDate(childReply.createdAt)}</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon">
                      <MoreVertical className="h-4 w-4 text-gray-500" />
                    </Button>
                  </div>
                  
                  <div className="text-gray-700 mb-2 ml-12 whitespace-pre-line">
                    {childReply.content}
                  </div>
                  
                  <div className="flex items-center ml-12">
                    <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary h-8 px-2">
                      <ThumbsUp className="h-3 w-3 mr-1" />
                      <span className="text-xs">3</span>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
