import { useState } from 'react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2 } from 'lucide-react';

interface ReplyFormProps {
  onSubmit: (content: string) => Promise<void>;
  onCancel: () => void;
  currentUserInitials: string;
  isPending?: boolean;
  placeholder?: string;
}

export default function ReplyForm({ 
  onSubmit, 
  onCancel, 
  currentUserInitials,
  isPending = false,
  placeholder = "Write your reply here..."
}: ReplyFormProps) {
  const [replyContent, setReplyContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handleSubmit = async () => {
    if (!replyContent.trim()) return;
    
    try {
      setIsSubmitting(true);
      await onSubmit(replyContent);
      setReplyContent('');
    } catch (error) {
      console.error('Error submitting reply:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const localIsPending = isSubmitting || isPending;
  
  return (
    <div className="mt-4 pl-2 border-l-2 border-primary/20">
      <div className="flex gap-3">
        <Avatar className="h-8 w-8 bg-primary">
          <AvatarFallback>{currentUserInitials}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <Textarea
            value={replyContent}
            onChange={(e) => setReplyContent(e.target.value)}
            placeholder={placeholder}
            className="min-h-[100px] mb-2 resize-none"
            disabled={localIsPending}
          />
          <div className="flex justify-end space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onCancel}
              disabled={localIsPending}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleSubmit}
              disabled={!replyContent.trim() || localIsPending}
              className="flex items-center"
            >
              {localIsPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  <span>Submitting...</span>
                </>
              ) : (
                <span>Submit</span>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}