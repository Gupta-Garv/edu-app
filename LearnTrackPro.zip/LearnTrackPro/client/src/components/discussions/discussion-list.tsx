import { useState } from 'react';
import { useLocation } from 'wouter';
import { Discussion } from '@shared/schema';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MessageSquare, Calendar, TrendingUp, Search } from 'lucide-react';

interface DiscussionListProps {
  discussions: Discussion[];
  isLoading: boolean;
  onNewDiscussion: () => void;
}

export default function DiscussionList({ 
  discussions, 
  isLoading,
  onNewDiscussion 
}: DiscussionListProps) {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('recent');
  const [filter, setFilter] = useState('all');
  
  // Format date to relative time
  const formatDate = (date: Date) => {
    const now = new Date();
    const discussionDate = new Date(date);
    const diffMs = now.getTime() - discussionDate.getTime();
    const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays < 1) {
      return 'Today';
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else if (diffDays < 30) {
      return `${Math.floor(diffDays / 7)} weeks ago`;
    } else {
      return discussionDate.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        year: discussionDate.getFullYear() !== now.getFullYear() ? 'numeric' : undefined 
      });
    }
  };
  
  // Get user initials for avatar
  const getUserInitials = (userId: number) => {
    return userId.toString().substring(0, 2).toUpperCase();
  };
  
  // Filter and sort discussions
  const filteredDiscussions = discussions.filter(discussion => {
    // Search filter
    if (searchQuery && !discussion.title.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Type filter
    if (filter === 'questions' && !discussion.title.includes('?')) {
      return false;
    } else if (filter === 'announcements' && !discussion.title.includes('[Announcement]')) {
      return false;
    }
    
    return true;
  }).sort((a, b) => {
    // Sort discussions
    if (sortBy === 'recent') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    } else if (sortBy === 'oldest') {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    } else if (sortBy === 'popular') {
      // This would ideally be based on reply count or likes
      // For now, just use a random value for demo purposes
      return b.id - a.id;
    }
    return 0;
  });
  
  return (
    <div>
      {/* Filters and search */}
      <div className="mb-6 space-y-4">
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div className="relative flex-1">
            <Input
              placeholder="Search discussions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10"
            />
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
          <div className="flex gap-2">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>Most Recent</span>
                  </div>
                </SelectItem>
                <SelectItem value="oldest">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>Oldest First</span>
                  </div>
                </SelectItem>
                <SelectItem value="popular">
                  <div className="flex items-center">
                    <TrendingUp className="h-4 w-4 mr-2" />
                    <span>Most Popular</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={onNewDiscussion}
              className="whitespace-nowrap"
            >
              New Discussion
            </Button>
          </div>
        </div>
        
        <Tabs defaultValue="all" className="w-full" onValueChange={setFilter}>
          <TabsList className="grid grid-cols-3 w-full max-w-md">
            <TabsTrigger value="all">All Topics</TabsTrigger>
            <TabsTrigger value="questions">Questions</TabsTrigger>
            <TabsTrigger value="announcements">Announcements</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
      
      {/* Discussion list */}
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <Card key={i} className="w-full animate-pulse">
              <CardContent className="p-6">
                <div className="h-6 bg-slate-200 rounded mb-4 w-3/4"></div>
                <div className="h-4 bg-slate-200 rounded mb-2 w-1/2"></div>
                <div className="h-4 bg-slate-200 rounded mb-4 w-full"></div>
                <div className="flex justify-between items-center">
                  <div className="h-8 bg-slate-200 rounded w-24"></div>
                  <div className="h-8 bg-slate-200 rounded w-24"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredDiscussions.length === 0 ? (
        <div className="text-center py-12 border border-dashed rounded-lg">
          <MessageSquare className="h-12 w-12 mx-auto text-gray-300 mb-3" />
          <h3 className="text-lg font-medium text-gray-900 mb-1">No discussions found</h3>
          <p className="text-gray-500 mb-4">
            {searchQuery ? 'Try adjusting your search or filter settings' : 'Be the first to start a discussion'}
          </p>
          {!searchQuery && (
            <Button onClick={onNewDiscussion}>
              Start a New Discussion
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredDiscussions.map(discussion => (
            <Card 
              key={discussion.id} 
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => setLocation(`/discussions/${discussion.id}`)}
            >
              <CardContent className="p-4">
                <div className="flex justify-between mb-2">
                  <div className="flex items-center">
                    <Avatar className="h-10 w-10 bg-primary">
                      <AvatarFallback>{getUserInitials(discussion.userId)}</AvatarFallback>
                    </Avatar>
                    <div className="ml-3">
                      <div className="flex items-center">
                        <p className="font-medium text-sm">User {discussion.userId}</p>
                        {discussion.title.includes('[Announcement]') && (
                          <Badge className="ml-2 bg-amber-500">Announcement</Badge>
                        )}
                      </div>
                      <p className="text-xs text-gray-500">
                        {formatDate(discussion.createdAt)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Badge variant="outline" className="flex items-center">
                      <MessageSquare className="h-3 w-3 mr-1" />
                      <span>12 replies</span>
                    </Badge>
                  </div>
                </div>
                <h4 className="font-medium mb-2 text-lg">{discussion.title}</h4>
                <p className="text-gray-700 text-sm mb-3 line-clamp-2">{discussion.content}</p>
                <div className="flex justify-end">
                  <Button
                    variant="link"
                    className="text-primary p-0 h-auto"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation(`/discussions/${discussion.id}`);
                    }}
                  >
                    View Discussion →
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}