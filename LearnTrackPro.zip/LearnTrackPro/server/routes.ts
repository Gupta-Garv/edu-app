import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { 
  insertCourseSchema, 
  insertModuleSchema, 
  insertLessonSchema, 
  insertDiscussionSchema, 
  insertReplySchema,
  insertProgressSchema,
  insertUserCourseSchema
} from "@shared/schema";
import { z } from "zod";

// Middleware to check if user is authenticated
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).send("Unauthorized");
}

// Middleware to check if user is admin
function isAdmin(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && req.user.isAdmin) {
    return next();
  }
  res.status(403).send("Forbidden");
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes (register, login, logout, user)
  setupAuth(app);

  // Courses routes
  app.get("/api/courses", async (req, res, next) => {
    try {
      const courses = await storage.getAllCourses();
      res.json(courses);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/courses/:id", async (req, res, next) => {
    try {
      const courseId = parseInt(req.params.id);
      const course = await storage.getCourseWithDetails(courseId);
      if (!course) {
        return res.status(404).send("Course not found");
      }
      res.json(course);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/courses", isAdmin, async (req, res, next) => {
    try {
      const courseData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(courseData);
      res.status(201).json(course);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ errors: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.put("/api/courses/:id", isAdmin, async (req, res, next) => {
    try {
      const courseId = parseInt(req.params.id);
      const courseData = insertCourseSchema.parse(req.body);
      const course = await storage.updateCourse(courseId, courseData);
      if (!course) {
        return res.status(404).send("Course not found");
      }
      res.json(course);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ errors: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.delete("/api/courses/:id", isAdmin, async (req, res, next) => {
    try {
      const courseId = parseInt(req.params.id);
      await storage.deleteCourse(courseId);
      res.status(204).send();
    } catch (error) {
      next(error);
    }
  });

  // Modules routes
  app.post("/api/modules", isAdmin, async (req, res, next) => {
    try {
      const moduleData = insertModuleSchema.parse(req.body);
      const module = await storage.createModule(moduleData);
      res.status(201).json(module);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ errors: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.put("/api/modules/:id", isAdmin, async (req, res, next) => {
    try {
      const moduleId = parseInt(req.params.id);
      const moduleData = insertModuleSchema.parse(req.body);
      const module = await storage.updateModule(moduleId, moduleData);
      if (!module) {
        return res.status(404).send("Module not found");
      }
      res.json(module);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ errors: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.delete("/api/modules/:id", isAdmin, async (req, res, next) => {
    try {
      const moduleId = parseInt(req.params.id);
      await storage.deleteModule(moduleId);
      res.status(204).send();
    } catch (error) {
      next(error);
    }
  });

  // Lessons routes
  app.post("/api/lessons", isAdmin, async (req, res, next) => {
    try {
      const lessonData = insertLessonSchema.parse(req.body);
      const lesson = await storage.createLesson(lessonData);
      res.status(201).json(lesson);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ errors: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.put("/api/lessons/:id", isAdmin, async (req, res, next) => {
    try {
      const lessonId = parseInt(req.params.id);
      const lessonData = insertLessonSchema.parse(req.body);
      const lesson = await storage.updateLesson(lessonId, lessonData);
      if (!lesson) {
        return res.status(404).send("Lesson not found");
      }
      res.json(lesson);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ errors: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.delete("/api/lessons/:id", isAdmin, async (req, res, next) => {
    try {
      const lessonId = parseInt(req.params.id);
      await storage.deleteLesson(lessonId);
      res.status(204).send();
    } catch (error) {
      next(error);
    }
  });

  // User courses (purchases) routes
  app.get("/api/user/courses", isAuthenticated, async (req, res, next) => {
    try {
      const userCourses = await storage.getUserCourses(req.user.id);
      res.json(userCourses);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/user/courses", isAuthenticated, async (req, res, next) => {
    try {
      const purchaseData = insertUserCourseSchema.parse({
        ...req.body,
        userId: req.user.id,
      });
      const purchase = await storage.purchaseCourse(purchaseData);
      res.status(201).json(purchase);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ errors: error.errors });
      } else {
        next(error);
      }
    }
  });

  // Progress tracking routes
  app.get("/api/user/progress", isAuthenticated, async (req, res, next) => {
    try {
      const progress = await storage.getUserProgress(req.user.id);
      res.json(progress);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/user/progress", isAuthenticated, async (req, res, next) => {
    try {
      const progressData = insertProgressSchema.parse({
        ...req.body,
        userId: req.user.id,
      });
      const progress = await storage.updateProgress(progressData);
      res.status(201).json(progress);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ errors: error.errors });
      } else {
        next(error);
      }
    }
  });

  // Discussion routes
  app.get("/api/courses/:courseId/discussions", async (req, res, next) => {
    try {
      const courseId = parseInt(req.params.courseId);
      const discussions = await storage.getCourseDiscussions(courseId);
      res.json(discussions);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/discussions/:id", async (req, res, next) => {
    try {
      const discussionId = parseInt(req.params.id);
      const discussion = await storage.getDiscussionWithDetails(discussionId);
      if (!discussion) {
        return res.status(404).send("Discussion not found");
      }
      res.json(discussion);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/discussions", isAuthenticated, async (req, res, next) => {
    try {
      const discussionData = insertDiscussionSchema.parse({
        ...req.body,
        userId: req.user.id,
      });
      const discussion = await storage.createDiscussion(discussionData);
      res.status(201).json(discussion);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ errors: error.errors });
      } else {
        next(error);
      }
    }
  });

  // Reply routes
  app.post("/api/replies", isAuthenticated, async (req, res, next) => {
    try {
      const replyData = insertReplySchema.parse({
        ...req.body,
        userId: req.user.id,
      });
      const reply = await storage.createReply(replyData);
      res.status(201).json(reply);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ errors: error.errors });
      } else {
        next(error);
      }
    }
  });

  // Get all recent discussions for dashboard
  app.get("/api/recent-discussions", isAuthenticated, async (req, res, next) => {
    try {
      const discussions = await storage.getRecentDiscussions();
      res.json(discussions);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
