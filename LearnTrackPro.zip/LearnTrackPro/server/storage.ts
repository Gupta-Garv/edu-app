import { 
  users, User, InsertUser,
  courses, Course, InsertCourse,
  modules, Module, InsertModule,
  lessons, Lesson, InsertLesson,
  userCourses, UserCourse, InsertUserCourse,
  progress, Progress, InsertProgress,
  discussions, Discussion, InsertDiscussion,
  replies, Reply, InsertReply,
  CourseWithDetails, DiscussionWithDetails
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { hashPassword } from "./passwordUtils";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Course methods
  getAllCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  getCourseWithDetails(id: number): Promise<CourseWithDetails | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: InsertCourse): Promise<Course | undefined>;
  deleteCourse(id: number): Promise<void>;
  
  // Module methods
  getModulesByCourseId(courseId: number): Promise<Module[]>;
  createModule(module: InsertModule): Promise<Module>;
  updateModule(id: number, module: InsertModule): Promise<Module | undefined>;
  deleteModule(id: number): Promise<void>;
  
  // Lesson methods
  getLessonsByModuleId(moduleId: number): Promise<Lesson[]>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  updateLesson(id: number, lesson: InsertLesson): Promise<Lesson | undefined>;
  deleteLesson(id: number): Promise<void>;
  
  // User courses methods
  getUserCourses(userId: number): Promise<Course[]>;
  purchaseCourse(purchase: InsertUserCourse): Promise<UserCourse>;
  
  // Progress methods
  getUserProgress(userId: number): Promise<Progress[]>;
  updateProgress(progress: InsertProgress): Promise<Progress>;
  
  // Discussion methods
  getCourseDiscussions(courseId: number): Promise<Discussion[]>;
  getDiscussionWithDetails(id: number): Promise<DiscussionWithDetails | undefined>;
  createDiscussion(discussion: InsertDiscussion): Promise<Discussion>;
  getRecentDiscussions(): Promise<DiscussionWithDetails[]>;
  
  // Reply methods
  createReply(reply: InsertReply): Promise<Reply>;
  
  // Session storage
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private courses: Map<number, Course>;
  private modules: Map<number, Module>;
  private lessons: Map<number, Lesson>;
  private userCourses: Map<number, UserCourse>;
  private progresses: Map<number, Progress>;
  private discussions: Map<number, Discussion>;
  private replies: Map<number, Reply>;
  
  sessionStore: session.Store;
  
  private userIdCounter: number;
  private courseIdCounter: number;
  private moduleIdCounter: number;
  private lessonIdCounter: number;
  private userCourseIdCounter: number;
  private progressIdCounter: number;
  private discussionIdCounter: number;
  private replyIdCounter: number;
  
  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.modules = new Map();
    this.lessons = new Map();
    this.userCourses = new Map();
    this.progresses = new Map();
    this.discussions = new Map();
    this.replies = new Map();
    
    this.userIdCounter = 1;
    this.courseIdCounter = 1;
    this.moduleIdCounter = 1;
    this.lessonIdCounter = 1;
    this.userCourseIdCounter = 1;
    this.progressIdCounter = 1;
    this.discussionIdCounter = 1;
    this.replyIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Create an admin user (with hashed password)
    this.createAdminUser();
  }
  
  private async createAdminUser() {
    const id = this.userIdCounter++;
    const now = new Date();
    const hashedPassword = await hashPassword('admin123');
    
    const user: User = {
      id,
      username: 'admin',
      password: hashedPassword,
      email: 'admin@learnhub.com',
      fullName: 'Admin User',
      isAdmin: true,
      createdAt: now
    };
    
    this.users.set(id, user);
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async createUser(userData: Partial<User>): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    
    // Hash the password if it's not already hashed
    let password = userData.password!;
    // Check if the password is already hashed (contains a period which separates hash and salt)
    if (!password.includes('.')) {
      password = await hashPassword(password);
    }
    
    const user: User = {
      id,
      username: userData.username!,
      password: password,
      email: userData.email!,
      fullName: userData.fullName!,
      isAdmin: userData.isAdmin || false,
      createdAt: now
    };
    this.users.set(id, user);
    return { ...user };
  }
  
  // Course methods
  async getAllCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }
  
  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }
  
  async getCourseWithDetails(id: number): Promise<CourseWithDetails | undefined> {
    const course = this.courses.get(id);
    if (!course) return undefined;
    
    const courseModules = await this.getModulesByCourseId(id);
    const modulesWithLessons = await Promise.all(
      courseModules.map(async (module) => {
        const moduleLessons = await this.getLessonsByModuleId(module.id);
        return {
          ...module,
          lessons: moduleLessons
        };
      })
    );
    
    return {
      ...course,
      modules: modulesWithLessons
    };
  }
  
  async createCourse(courseData: InsertCourse): Promise<Course> {
    const id = this.courseIdCounter++;
    const now = new Date();
    const course: Course = {
      id,
      ...courseData,
      createdAt: now,
      updatedAt: now
    };
    this.courses.set(id, course);
    return { ...course };
  }
  
  async updateCourse(id: number, courseData: InsertCourse): Promise<Course | undefined> {
    const course = this.courses.get(id);
    if (!course) return undefined;
    
    const updatedCourse: Course = {
      ...course,
      ...courseData,
      updatedAt: new Date()
    };
    this.courses.set(id, updatedCourse);
    return { ...updatedCourse };
  }
  
  async deleteCourse(id: number): Promise<void> {
    this.courses.delete(id);
    
    // Delete related data
    const modulesToDelete = Array.from(this.modules.values())
      .filter(module => module.courseId === id);
      
    for (const module of modulesToDelete) {
      await this.deleteModule(module.id);
    }
    
    // Delete user purchases
    const purchasesToDelete = Array.from(this.userCourses.values())
      .filter(purchase => purchase.courseId === id);
      
    for (const purchase of purchasesToDelete) {
      this.userCourses.delete(purchase.id);
    }
    
    // Delete discussions
    const discussionsToDelete = Array.from(this.discussions.values())
      .filter(discussion => discussion.courseId === id);
      
    for (const discussion of discussionsToDelete) {
      this.discussions.delete(discussion.id);
    }
  }
  
  // Module methods
  async getModulesByCourseId(courseId: number): Promise<Module[]> {
    return Array.from(this.modules.values())
      .filter(module => module.courseId === courseId)
      .sort((a, b) => a.order - b.order);
  }
  
  async createModule(moduleData: InsertModule): Promise<Module> {
    const id = this.moduleIdCounter++;
    const module: Module = {
      id,
      ...moduleData
    };
    this.modules.set(id, module);
    return { ...module };
  }
  
  async updateModule(id: number, moduleData: InsertModule): Promise<Module | undefined> {
    const module = this.modules.get(id);
    if (!module) return undefined;
    
    const updatedModule: Module = {
      ...module,
      ...moduleData
    };
    this.modules.set(id, updatedModule);
    return { ...updatedModule };
  }
  
  async deleteModule(id: number): Promise<void> {
    this.modules.delete(id);
    
    // Delete lessons
    const lessonsToDelete = Array.from(this.lessons.values())
      .filter(lesson => lesson.moduleId === id);
      
    for (const lesson of lessonsToDelete) {
      this.lessons.delete(lesson.id);
    }
  }
  
  // Lesson methods
  async getLessonsByModuleId(moduleId: number): Promise<Lesson[]> {
    return Array.from(this.lessons.values())
      .filter(lesson => lesson.moduleId === moduleId)
      .sort((a, b) => a.order - b.order);
  }
  
  async createLesson(lessonData: InsertLesson): Promise<Lesson> {
    const id = this.lessonIdCounter++;
    const lesson: Lesson = {
      id,
      ...lessonData
    };
    this.lessons.set(id, lesson);
    return { ...lesson };
  }
  
  async updateLesson(id: number, lessonData: InsertLesson): Promise<Lesson | undefined> {
    const lesson = this.lessons.get(id);
    if (!lesson) return undefined;
    
    const updatedLesson: Lesson = {
      ...lesson,
      ...lessonData
    };
    this.lessons.set(id, updatedLesson);
    return { ...updatedLesson };
  }
  
  async deleteLesson(id: number): Promise<void> {
    this.lessons.delete(id);
    
    // Delete progress records
    const progressesToDelete = Array.from(this.progresses.values())
      .filter(progress => progress.lessonId === id);
      
    for (const progress of progressesToDelete) {
      this.progresses.delete(progress.id);
    }
  }
  
  // User courses methods
  async getUserCourses(userId: number): Promise<Course[]> {
    const userPurchases = Array.from(this.userCourses.values())
      .filter(purchase => purchase.userId === userId);
      
    const courses = userPurchases.map(purchase => 
      this.courses.get(purchase.courseId)
    ).filter((course): course is Course => !!course);
    
    return courses;
  }
  
  async purchaseCourse(purchaseData: InsertUserCourse): Promise<UserCourse> {
    const id = this.userCourseIdCounter++;
    const now = new Date();
    const purchase: UserCourse = {
      id,
      ...purchaseData,
      purchasedAt: now
    };
    this.userCourses.set(id, purchase);
    return { ...purchase };
  }
  
  // Progress methods
  async getUserProgress(userId: number): Promise<Progress[]> {
    return Array.from(this.progresses.values())
      .filter(progress => progress.userId === userId);
  }
  
  async updateProgress(progressData: InsertProgress): Promise<Progress> {
    // Check if progress record exists
    const existingProgress = Array.from(this.progresses.values())
      .find(p => p.userId === progressData.userId && p.lessonId === progressData.lessonId);
      
    if (existingProgress) {
      // Update existing record
      const updatedProgress: Progress = {
        ...existingProgress,
        ...progressData,
        lastWatchedAt: new Date()
      };
      this.progresses.set(existingProgress.id, updatedProgress);
      return { ...updatedProgress };
    } else {
      // Create new record
      const id = this.progressIdCounter++;
      const now = new Date();
      const progress: Progress = {
        id,
        ...progressData,
        lastWatchedAt: now
      };
      this.progresses.set(id, progress);
      return { ...progress };
    }
  }
  
  // Discussion methods
  async getCourseDiscussions(courseId: number): Promise<Discussion[]> {
    return Array.from(this.discussions.values())
      .filter(discussion => discussion.courseId === courseId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async getDiscussionWithDetails(id: number): Promise<DiscussionWithDetails | undefined> {
    const discussion = this.discussions.get(id);
    if (!discussion) return undefined;
    
    const user = this.users.get(discussion.userId);
    if (!user) return undefined;
    
    const discussionReplies = Array.from(this.replies.values())
      .filter(reply => reply.discussionId === id && !reply.parentId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
    
    const repliesWithUsers = discussionReplies.map(reply => {
      const replyUser = this.users.get(reply.userId);
      
      // Get child replies
      const childReplies = Array.from(this.replies.values())
        .filter(r => r.parentId === reply.id)
        .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())
        .map(childReply => {
          const childUser = this.users.get(childReply.userId);
          return {
            ...childReply,
            user: childUser!
          };
        });
      
      return {
        ...reply,
        user: replyUser!,
        childReplies
      };
    });
    
    return {
      ...discussion,
      user,
      replies: repliesWithUsers
    };
  }
  
  async createDiscussion(discussionData: InsertDiscussion): Promise<Discussion> {
    const id = this.discussionIdCounter++;
    const now = new Date();
    const discussion: Discussion = {
      id,
      ...discussionData,
      createdAt: now
    };
    this.discussions.set(id, discussion);
    return { ...discussion };
  }
  
  async getRecentDiscussions(): Promise<DiscussionWithDetails[]> {
    const recentDiscussions = Array.from(this.discussions.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, 5);
    
    const discussionsWithDetails = await Promise.all(
      recentDiscussions.map(async (discussion) => 
        (await this.getDiscussionWithDetails(discussion.id))!
      )
    );
    
    return discussionsWithDetails.filter(Boolean);
  }
  
  // Reply methods
  async createReply(replyData: InsertReply): Promise<Reply> {
    const id = this.replyIdCounter++;
    const now = new Date();
    const reply: Reply = {
      id,
      ...replyData,
      createdAt: now
    };
    this.replies.set(id, reply);
    return { ...reply };
  }
}

export const storage = new MemStorage();
