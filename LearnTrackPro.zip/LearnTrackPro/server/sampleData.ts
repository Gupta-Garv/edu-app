import { storage } from './storage';
import { InsertCourse, InsertModule, InsertLesson } from '@shared/schema';

// Sample course data
const sampleCourses: InsertCourse[] = [
  {
    title: 'Introduction to Web Development',
    description: 'Learn the basics of web development including HTML, CSS, and JavaScript.',
    price: 4999, // Store as integer (in cents)
    thumbnail: 'https://images.unsplash.com/photo-1593720213428-28a5b9e94613?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    category: 'Web Development',
    duration: '4 weeks',
    instructor: 'John Smith'
  },
  {
    title: 'Advanced React Techniques',
    description: 'Master advanced React concepts including hooks, context, and performance optimization.',
    price: 7999, // Store as integer (in cents)
    thumbnail: 'https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    category: 'JavaScript Frameworks',
    duration: '6 weeks',
    instructor: 'Sarah Johnson'
  },
  {
    title: 'Node.js Backend Development',
    description: 'Build scalable backend applications with Node.js and Express.',
    price: 6999, // Store as integer (in cents)
    thumbnail: 'https://images.unsplash.com/photo-1580894732930-0babd100d356?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    category: 'Backend Development',
    duration: '5 weeks',
    instructor: 'Michael Chen'
  }
];

// Sample modules and lessons
const webDevModules: InsertModule[] = [
  {
    title: 'HTML Fundamentals',
    description: 'Learn the building blocks of the web',
    courseId: 1, // Will be set dynamically
    order: 1
  },
  {
    title: 'CSS Styling',
    description: 'Make your websites beautiful with CSS',
    courseId: 1, // Will be set dynamically
    order: 2
  },
  {
    title: 'JavaScript Basics',
    description: 'Add interactivity to your websites',
    courseId: 1, // Will be set dynamically
    order: 3
  }
];

const reactModules: InsertModule[] = [
  {
    title: 'React Hooks Deep Dive',
    description: 'Master all React hooks and create custom hooks',
    courseId: 2, // Will be set dynamically
    order: 1
  },
  {
    title: 'Context API and State Management',
    description: 'Learn global state management without Redux',
    courseId: 2, // Will be set dynamically
    order: 2
  },
  {
    title: 'Performance Optimization',
    description: 'Make your React apps blazing fast',
    courseId: 2, // Will be set dynamically
    order: 3
  }
];

const nodeModules: InsertModule[] = [
  {
    title: 'Express Framework',
    description: 'Build robust APIs with Express',
    courseId: 3, // Will be set dynamically
    order: 1
  },
  {
    title: 'Database Integration',
    description: 'Connect your Node.js apps to databases',
    courseId: 3, // Will be set dynamically
    order: 2
  },
  {
    title: 'Authentication and Authorization',
    description: 'Secure your Node.js applications',
    courseId: 3, // Will be set dynamically
    order: 3
  }
];

// Sample lessons
const htmlLessons: InsertLesson[] = [
  {
    title: 'HTML Document Structure',
    description: 'Learn the basic structure of an HTML document',
    moduleId: 1, // Will be set dynamically
    order: 1,
    duration: '15 minutes',
    videoUrl: 'https://www.youtube.com/embed/UB1O30fR-EE'
  },
  {
    title: 'HTML Elements and Attributes',
    description: 'Explore common HTML elements and their attributes',
    moduleId: 1, // Will be set dynamically
    order: 2,
    duration: '20 minutes',
    videoUrl: 'https://www.youtube.com/embed/UB1O30fR-EE'
  }
];

// Initialize sample data
export async function initializeSampleData() {
  try {
    // Check if courses already exist
    const existingCourses = await storage.getAllCourses();
    if (existingCourses.length > 0) {
      console.log('Sample data already initialized.');
      return;
    }

    console.log('Initializing sample data...');

    // Create courses
    const createdCourses = await Promise.all(
      sampleCourses.map(course => storage.createCourse(course))
    );

    // Create modules for the first course (Web Development)
    const webDevCourse = createdCourses[0];
    const webDevModulesWithCourseId = webDevModules.map(module => ({
      ...module,
      courseId: webDevCourse.id
    }));
    
    const createdWebDevModules = await Promise.all(
      webDevModulesWithCourseId.map(module => storage.createModule(module))
    );

    // Create modules for the second course (React)
    const reactCourse = createdCourses[1];
    const reactModulesWithCourseId = reactModules.map(module => ({
      ...module,
      courseId: reactCourse.id
    }));
    
    const createdReactModules = await Promise.all(
      reactModulesWithCourseId.map(module => storage.createModule(module))
    );

    // Create modules for the third course (Node.js)
    const nodeCourse = createdCourses[2];
    const nodeModulesWithCourseId = nodeModules.map(module => ({
      ...module,
      courseId: nodeCourse.id
    }));
    
    const createdNodeModules = await Promise.all(
      nodeModulesWithCourseId.map(module => storage.createModule(module))
    );

    // Create lessons for the first module (HTML)
    const htmlModule = createdWebDevModules[0];
    const htmlLessonsWithModuleId = htmlLessons.map(lesson => ({
      ...lesson,
      moduleId: htmlModule.id
    }));
    
    await Promise.all(
      htmlLessonsWithModuleId.map(lesson => storage.createLesson(lesson))
    );

    console.log('Sample data initialized successfully');
  } catch (error) {
    console.error('Error initializing sample data:', error);
  }
}